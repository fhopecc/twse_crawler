from unittest.mock import patch
import unittest

class Test(unittest.TestCase):
    '依方法名稱字母順序測試'
    def test(self):
        from twse_crawler.預估次年底 import 依外部季數據預估次年底數值
        from twse_crawler.預估次年底 import 預估至次年底每月值
        from twse_crawler.預估次年底 import 預估至次年底每季值
        from twse_crawler.預估次年底 import 以外部季數據預估次年底各月值
        from twse_crawler.預估次年底 import 以外部季數據預估次年底各月值乙式
        from twse_crawler.預估次年底 import 預估至次年底每季值乙式
        from zhongwen.表 import 表示
        from twse_crawler.鉛價分析 import 取鉛價
        from twse_crawler.財報分析 import 取財報彙總表
        from twse_crawler.資產負債表分析 import 取資產負債表
        from twse_crawler.營收分析 import 以營收預測次年每股盈餘
        from twse_crawler.鉛價分析 import 以鉛價預測次年每股盈餘, cache
        from twse_crawler.營收分析 import 取歷月營收表
        from twse_crawler.損益表分析 import 以淨利預測次年每股盈餘, 取損益表
        from twse_crawler.營收預測營利模型 import 以營收預測次年每股盈餘
        from zhongwen import 快取
        import pandas as pd
        r = 以營收預測次年每股盈餘('中宇')
        表示(r)
        self.assertFalse(True)
        h = 取損益表('一零四')
        r = 預估至次年底每季值乙式(h.淨利)
        表示(r)
        股票 = '一零四'
        h = 取歷月營收表(股票)
        q = 取資產負債表(股票)
        r1 = 預估至次年底每月值(h.營收)
        表示(r1)
        r2 = 以外部季數據預估次年底各月值(h.營收, q[['合約負債－流動']])
        表示(r2)
        # r3 = 以外部季數據預估次年底各月值乙式(h.營收, q[['合約負債－流動']])
        # 表示(r3)
        self.assertFalse(True)
        快取.停止快取 = True
        cache.clear() 
        股票 = '新麥'
        r = 以營收預測次年每股盈餘(股票)
        表示(r, 顯示索引=True)

        r = 取歷月營收表('泰銘').set_index('營收月份').營收
        r = 預估至次年底每月值(r)
        表示(r.預估每月值.tail(36), 顯示索引=True) 

        歷季損益表 = 取財報彙總表('泰銘')
        歷季損益表 = 歷季損益表.set_index(歷季損益表.財報日期.dt.to_period('Q'))
        r = 預估至次年底每季值(歷季損益表.業外損益)
        表示(r.預估每季值, 顯示索引=True) 
 
        表示(r.預估價, 顯示索引=True) 
        表示(r.預估季價, 顯示索引=True) 
 
if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    logging.getLogger('googleclient').setLevel(logging.CRITICAL)
    logging.getLogger('matplotlib').setLevel(logging.CRITICAL)
    logging.getLogger('faker').setLevel(logging.CRITICAL)
    unittest.main()
    suite = unittest.TestSuite()
    suite.addTest(Test('test'))  # 指定測試
    unittest.TextTestRunner().run(suite)
